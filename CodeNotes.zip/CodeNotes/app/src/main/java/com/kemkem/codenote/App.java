package com.kemkem.codenote;

import android.app.Application;
import android.content.Context;
import com.kemkem.codenote.Key.Keystore;
import com.kemkem.codenote.Key.SimpleKeystore;
import com.kemkem.codenote.Repository.FileNoteRepository;
import com.kemkem.codenote.Repository.NoteRepository;

import java.io.File;

public class App extends Application {

    private static Keystore keystore;
    private static NoteRepository noteRepository;

    @Override
    public void onCreate() {
        super.onCreate();
        keystore = new SimpleKeystore(getSharedPreferences("password_text", Context.MODE_PRIVATE));
        final File notesRoot = new File(getFilesDir(), "notes");
        //noinspection ResultOfMethodCallIgnored
        notesRoot.mkdir();
        noteRepository = new FileNoteRepository(notesRoot);

    }

    public static Keystore getKeystore() {
        return keystore;
    }

    public static NoteRepository getNoteRepository() {
        return noteRepository;
    }

}

